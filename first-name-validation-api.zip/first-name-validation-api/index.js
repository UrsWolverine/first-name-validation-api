const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Endpoint for the First name validation
app.post('/validate-first-name', (req, res) => {
    const{ firstName } = req.body;

    // Check if the first name is 'Mascot'
    if (!firstName){
        return res.status(400).json({error: 'First name is required'});
    }
    if (firstName === 'Mascot' || firstName ==='mascot'){
        return res.status(200).json({ isValid: false, message: 'The firstName cannot be "Mascot".'});
    }

    // Otherwise, return Valid
    res.status(200).json({ isValid: true});
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is runnning on port ${PORT}`);
});